# Events app

Flutter events app UI that consist of 3 screens home screen, event screen, and profile screen.

## YouTube Link:

[Flutter Events app UI | Speed Code](https://youtu.be/ozgOU9C3vF4)

